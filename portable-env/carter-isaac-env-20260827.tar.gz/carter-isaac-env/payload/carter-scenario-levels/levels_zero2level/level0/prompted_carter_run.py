"""Mission runner - identical file for every level (zero2level track).

The mission is NOT hard-coded here: the level comes from the parent folder
name (level0..level3) and its givens from the MISSIONS table below.  What
the controller must accomplish is specified by that level's PROMPT.md.

PASS criteria are evaluated by the fixed harness (levels/common/carter_env.py):
  reached_goal      final distance <= position tolerance
                    (and |yaw error| <= yaw tolerance when it is set)
  no_collision      zero chassis contact events (when collision is scored)
  max_time_to_goal  first entry into the goal disc within the bound (when set)
  timeout_s         sim-time budget

ROBOT API available to the controller:
  controller(t, pose, env) is called once per 1/60 s sim step and must
  return (v, w, done):
    t     sim seconds since mission start
    pose  (x, y, yaw) ground-truth world pose of the chassis
    env   harness handle: env.raycast_scan(n_beams=61, fov_deg=180.0,
          z=0.35, max_range=6.0) -> [(bearing_rel_to_heading, distance_m),
          ...] - a planar PhysX ray fan around the current heading;
          distance == max_range means nothing hit on that bearing
    v     forward velocity command [m/s] on /cmd_vel
    w     yaw rate command [rad/s] on /cmd_vel
    done  True ends the mission (harness then stops the robot and evaluates)

The ONLY part meant to be modified to solve a level is the block marked
[EDIT REGION].  Everything outside it is fixed plumbing, byte-identical
across all four levels and all variants.
"""

import math  # noqa: F401  (available to the controller)
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "levels" / "common"))
from carter_env import Harness  # noqa: E402

LEVEL = Path(__file__).resolve().parent.name              # "level0" .. "level3"
VARIANT = Path(__file__).stem.replace("_carter_run", "")  # "base" | <model name>
OUT = str(Path(__file__).resolve().parent / "results")

# scenario givens per level (from scenarios/*.yaml - not part of the answer)
MISSIONS = {
    "level0": dict(goal_xy_yaw=(-8.0, -1.0, 3.14159265), timeout_s=60.0,
                   position_tolerance_m=1.0, yaw_tolerance_rad=None,
                   max_time_to_goal_s=None, check_collision=False,
                   obstacle=None),
    "level1": dict(goal_xy_yaw=(-6.0, 5.0, 1.5708), timeout_s=120.0,
                   position_tolerance_m=0.75, yaw_tolerance_rad=0.26,
                   max_time_to_goal_s=None, check_collision=True,
                   obstacle=None),
    "level2": dict(goal_xy_yaw=(-6.0, 5.0, 1.5708), timeout_s=120.0,
                   position_tolerance_m=0.75, yaw_tolerance_rad=0.26,
                   max_time_to_goal_s=None, check_collision=True,
                   obstacle={"x": -6.2, "y": 2.0,
                             "height": 1.0, "width": 0.8, "depth": 0.6}),
    "level3": dict(goal_xy_yaw=(-6.0, 5.0, 1.5708), timeout_s=120.0,
                   position_tolerance_m=0.75, yaw_tolerance_rad=0.26,
                   max_time_to_goal_s=12.0, check_collision=True,
                   obstacle={"x": -6.2, "y": 3.5,
                             "height": 1.0, "width": 0.8, "depth": 0.6}),
}
M = MISSIONS[LEVEL]
GOAL = M["goal_xy_yaw"]  # (x, y, yaw) - available to the controller

# ===========================================================================
# [EDIT REGION] mission controller - modify ONLY this block
# ===========================================================================


GOAL_X, GOAL_Y = GOAL[0], GOAL[1]


def controller(t, pose, env):
    """Level 0: forward-only reach.

    The goal lies straight ahead of the spawn heading, so w stays 0 at all
    times.  Drive forward with a speed proportional to the remaining
    distance (capped), and declare done once well inside the 1.0 m
    tolerance.  Purely a function of (pose,) -> deterministic.
    """
    x, y, _yaw = pose
    dist = math.hypot(GOAL_X - x, GOAL_Y - y)

    STOP_DIST = 0.15   # finish well inside the 1.0 m tolerance
    V_MAX = 0.8        # cruise speed [m/s]
    K_P = 1.5          # slow-down gain near the goal

    if dist <= STOP_DIST:
        return 0.0, 0.0, True

    v = min(V_MAX, K_P * dist)
    v = max(v, 0.05)   # keep creeping forward until STOP_DIST is reached
    return v, 0.0, False


# ========================= [END EDIT REGION] ===============================

h = Harness(level=LEVEL, variant=VARIANT, out_dir=OUT, **M).boot()
result = h.run_mission(controller, abort_after_collision_s=5.0)
h.close()
sys.exit(0 if result["verdict"] == "pass" else 1)
